# Weekly Review — [YYYY-MM-DD]

- Phase:
- Planned hours:
- Actual hours:

## Three things I can explain without notes

## Work completed and evidence

## Biggest misconception corrected

## Problems still open

## Retrieval practice / assessment results

## Next week's specific objective
