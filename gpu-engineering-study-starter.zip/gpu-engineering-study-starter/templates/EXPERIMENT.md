# Experiment: [Title]

- Date:
- Commit:
- Machine and environment (`docs/ENVIRONMENT.md`):
- Workload / input shape:
- Numerical correctness criterion:

## Question and falsifiable hypothesis

## Baseline and candidate

## Controlled variables

## Independent variable

## Timing boundaries (compile / transfer / GPU / end-to-end)

## Warmup and repetitions

## Raw data location

## Summary statistics (median, spread, sample size)

## Model / expected result

## Observations (facts only)

## Interpretation and competing explanations

## Limitations / uncertainty

## Reproduction commands

## Next experiment
