# Project: [Name]

## Problem and motivation

## Scope / non-goals

## Functional requirements

## Nonfunctional requirements

## Architecture sketch

## Correctness invariants

## Failure behavior

## Milestones and acceptance criteria

## Test plan

## Performance baseline and methodology

## Risks and unknowns

## Final technical defense questions

## Retrospective
