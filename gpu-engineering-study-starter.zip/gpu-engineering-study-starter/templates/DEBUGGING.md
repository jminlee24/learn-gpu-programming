# Debugging Investigation: [Symptom]

- Date:
- Phase / project:
- Commit / environment:

## Expected behavior

## Actual behavior

## Smallest reproducer

## Known facts

## Hypotheses ranked by plausibility

## Experiments performed

## Root cause (only after evidence)

## Regression test

## What I learned
