# Lab: [Title]

- Phase / module:
- Date:
- Time spent:
- Source references:

## Objective

## Prediction / hypothesis

## Setup and assumptions

## Independent work performed

## Tests and observations

## Explanation from first principles

## Mistakes and surprises

## Remaining questions

## Evidence links (commits, output, tests)

## Follow-up
