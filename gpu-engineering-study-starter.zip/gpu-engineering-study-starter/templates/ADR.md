# ADR-NNN: [Decision]

- Date:
- Status: Proposed / Accepted / Superseded

## Context

## Requirements and constraints

## Options considered

## Decision

## Why this option

## Consequences and risks

## Evidence and follow-up
