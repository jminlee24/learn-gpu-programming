# Projects

Create one directory per project. Use `templates/PROJECT.md`. Keep each Rust/C++ build self-contained unless sharing code has a clear engineering purpose. Avoid adding GPU dependencies until a phase requires them.
