# Experiments

Create one subdirectory per experiment. Copy `templates/EXPERIMENT.md`, retain raw data, and record reproduction commands. Never modify raw measurements to improve plots.

Suggested CSV fields: `timestamp,commit,device,driver,workload,input_size,variant,warmup_runs,trial,elapsed_ns,correct`.
