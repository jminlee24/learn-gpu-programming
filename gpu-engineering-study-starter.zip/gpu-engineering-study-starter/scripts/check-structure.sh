#!/usr/bin/env bash
set -euo pipefail
for f in README.md PROGRESS.md docs/LEARNING_PROTOCOL.md docs/AI_TUTOR_POLICY.md templates/LAB.md templates/EXPERIMENT.md; do
  test -f "$f" || { echo "Missing: $f" >&2; exit 1; }
done
for i in $(seq -w 0 15); do
  compgen -G "phases/${i}-*" >/dev/null || { echo "Missing phase ${i}" >&2; exit 1; }
done
echo "Study repository structure OK"
