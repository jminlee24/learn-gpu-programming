# Phase Manuals

Optional: export the 16 phase manuals here as Markdown or PDF. The starter repository does not include those documents. Keep original versions for comparison if you revise a manual.
