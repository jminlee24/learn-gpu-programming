# Development Environment Record

- Date:
- Fedora release:
- Kernel (`uname -r`):
- CPU:
- RAM:
- GPU: AMD Radeon RX 9070 16 GB
- GPU driver / Mesa version:
- Vulkan loader / driver details:
- Rust (`rustc --version`):
- Cargo (`cargo --version`):
- C++ compiler (`c++ --version`):
- Git version:
- Notes on installed tooling:

Do not commit serial numbers, tokens, account names, or private machine identifiers.

## Verification (run when applicable)
```bash
uname -r
rustc --version
cargo --version
c++ --version
vulkaninfo --summary
```

Some tools may not yet be installed. Record missing tools rather than installing everything before Phase 0.
