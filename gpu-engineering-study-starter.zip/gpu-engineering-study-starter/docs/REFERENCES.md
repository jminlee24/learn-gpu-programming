# Reference Library

## Foundations
- Rust book: https://doc.rust-lang.org/book/
- Cargo: https://doc.rust-lang.org/cargo/
- C++ reference: https://en.cppreference.com/
- OSTEP: https://pages.cs.wisc.edu/~remzi/OSTEP/

## GPU
- WGSL specification: https://www.w3.org/TR/WGSL/
- wgpu docs: https://docs.rs/wgpu/
- Vulkan specification: https://registry.khronos.org/vulkan/
- Mesa RADV: https://docs.mesa3d.org/drivers/radv.html
- GPUOpen: https://gpuopen.com/

## Compiler
- LLVM: https://llvm.org/docs/
- SPIR-V registry: https://registry.khronos.org/SPIR-V/

Record the specific sections, versions, and dates consulted in individual notes.
