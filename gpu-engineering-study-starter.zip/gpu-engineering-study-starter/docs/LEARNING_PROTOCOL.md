# Learning Operations Handbook

## Weekly cadence (10–12 hours)
- 2 h: concept reading and independent derivations.
- 4–5 h: implementation and labs.
- 2 h: experiments, debugging, and validation.
- 1–2 h: retrieval practice and quizzes.
- 1 h: weekly retrospective and planning.

Adjust allocation based on phase; do not force every week to be identical.

## Session protocol
1. Write a learning objective and a falsifiable question.
2. Recall prior knowledge before opening references.
3. Study a focused concept, then work independently.
4. Run or reason through a concrete experiment.
5. Record observations separately from interpretations.
6. Close with a 3–5 sentence explanation from memory.

## Stuck protocol
After 20–30 minutes, write what is known, what was attempted, the smallest reproducer, and one question. Consult docs or a strictly Socratic tutor. Do not copy solutions into assessed work.

## Mastery gate
- Explain the idea from first principles without notes.
- Complete required implementation and tests independently.
- Explain failure cases and tradeoffs.
- Meet the manual's quiz/exam/project criteria.
- Link evidence in `PROGRESS.md`.

## Review cadence
Review difficult topics after roughly 1 day, 1 week, and 1 month; prioritize retrieval practice over rereading.

## Weekly review questions
What did I understand? What can I demonstrate? What failed? What evidence changed my view? What will I do next?
