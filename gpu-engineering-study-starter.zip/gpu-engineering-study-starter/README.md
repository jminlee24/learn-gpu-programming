# GPU Engineering Study Repository

A 16-phase, evidence-based learning workspace. **Start with Phase 00.** Do not fill in projects or assessments using AI-generated solutions.

## First session
1. Read `docs/LEARNING_PROTOCOL.md` and `docs/AI_TUTOR_POLICY.md`.
2. Record your machine in `docs/ENVIRONMENT.md` (avoid committing private identifiers).
3. Open `phases/00-foundations/README.md` and create your first lab entry using `templates/LAB.md`.
4. Update `PROGRESS.md` only after completing evidence-backed work.

## Organization
- `phases/`: one folder per phase; each has notes, exercises, projects, assessments, and a phase README.
- `templates/`: reusable blank worksheets for labs, experiments, ADRs, debugging, quizzes, and project planning.
- `docs/`: study process, environment, references, and tutor policy.
- `experiments/`: reproducible measurements, metadata, and analyses.
- `projects/`: substantial independent projects; create actual Rust/C++ projects here when needed.
- `scripts/`: local checks; do not treat their success as proof of mastery.

## Tooling
This is intentionally **not** a single Cargo workspace. Early phases include math, logic, and C++; later phases may need separate Rust workspaces with different dependencies and targets. Create Cargo workspaces within individual projects when appropriate.

Run `bash scripts/check-structure.sh` to verify basic repository structure.

## Phase advancement
Advance when the manual's required projects and assessments are complete, errors are reviewed, and you can explain the work without assistance. See `docs/LEARNING_PROTOCOL.md`.

## Manuals
Place your exported phase manuals under `manuals/` if desired; they are not included in this starter archive. Keep version history for changes to learning materials.
