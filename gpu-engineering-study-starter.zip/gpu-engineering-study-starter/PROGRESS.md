# Curriculum Progress

**Current phase:** 00 — Mathematical and Computational Foundations  
**Start date:**  
**Study hours logged:** 0

| Phase | Topic | Status | Hours | Evidence |
|---|---|---|---:|---|
| 00 | Foundations | Not started | 0 | — |
| 01 | Rust systems | Not started | 0 | — |
| 02 | Modern C++ | Not started | 0 | — |
| 03 | Computer architecture | Not started | 0 | — |
| 04 | Operating systems | Not started | 0 | — |
| 05 | Math and numerical computing | Not started | 0 | — |
| 06 | Concurrency and parallel algorithms | Not started | 0 | — |
| 07 | GPU architecture | Not started | 0 | — |
| 08 | Portable GPU programming | Not started | 0 | — |
| 09 | CUDA | Not started | 0 | — |
| 10 | GPU optimization | Not started | 0 | — |
| 11 | Advanced parallel algorithms | Not started | 0 | — |
| 12 | Native Rust GPU | Not started | 0 | — |
| 13 | GPU runtimes | Not started | 0 | — |
| 14 | GPU compilers | Not started | 0 | — |
| 15 | Specialization and capstone | Not started | 0 | — |

Status values: Not started / In progress / Review needed / Completed.

## Current week's objective

## Evidence of mastery

## Topics to revisit

## Next action
