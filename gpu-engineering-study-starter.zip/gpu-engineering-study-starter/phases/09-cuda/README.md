# Phase 09: Cuda

**Status:** Not started  
**Start:**  
**Finish:**

## Manual and references

## Learning objectives

## Labs and exercises

## Assessments

## Required project(s)

## Mastery evidence

## Mistakes to revisit

## Completion decision
