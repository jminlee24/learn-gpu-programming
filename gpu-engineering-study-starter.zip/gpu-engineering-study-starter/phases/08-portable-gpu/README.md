# Phase 08: Portable Gpu

**Status:** Not started  
**Start:**  
**Finish:**

## Manual and references

## Learning objectives

## Labs and exercises

## Assessments

## Required project(s)

## Mastery evidence

## Mistakes to revisit

## Completion decision
