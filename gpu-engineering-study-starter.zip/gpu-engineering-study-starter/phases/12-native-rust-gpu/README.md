# Phase 12: Native Rust Gpu

**Status:** Not started  
**Start:**  
**Finish:**

## Manual and references

## Learning objectives

## Labs and exercises

## Assessments

## Required project(s)

## Mastery evidence

## Mistakes to revisit

## Completion decision
