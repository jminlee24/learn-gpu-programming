# Phase 11: Advanced Parallel Algorithms

**Status:** Not started  
**Start:**  
**Finish:**

## Manual and references

## Learning objectives

## Labs and exercises

## Assessments

## Required project(s)

## Mastery evidence

## Mistakes to revisit

## Completion decision
